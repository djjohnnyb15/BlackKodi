import xbmcgui,xbmcplugin

plugin_handle = int(sys.argv[1])
_id = 'plugin.video.EasyIPTV'
_icondir = "special://home/addons/" + _id + "/icons/"

def add_video_item(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

# Entertainment
add_video_item('https://raw.githubusercontent.com/djjohnnyb15/Easyiptv/master/uktv.m3u',{ 'title': 'UK TV'}, '%s/uktv.png'% _icondir)
add_video_item('https://raw.githubusercontent.com/djjohnnyb15/Easyiptv/master/sports.m3u',{ 'title': 'Sport'}, '%s/sport.gif'% _icondir)





xbmcplugin.endOfDirectory(plugin_handle)
xbmc.executebuiltin("Container.SetViewMode(500)")

